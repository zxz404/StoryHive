const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  PUSH_PUBLIC_KEY: 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk',
  CACHE_NAME: 'storyhive-pwa-v4',
  API_CACHE_NAME: 'storyhive-api-v1'
};

export default CONFIG;
