const Config = {
  API_BASE_URL: 'https://story-api.dicoding.dev/v1',
  VAPID_PUBLIC_KEY: 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk' // Ganti dengan VAPID public key dari API
};

export default Config;
export const { API_BASE_URL, VAPID_PUBLIC_KEY } = Config;